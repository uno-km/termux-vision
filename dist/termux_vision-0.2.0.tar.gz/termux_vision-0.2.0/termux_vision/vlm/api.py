import os
import tempfile
from typing import Union, Dict, Any, Optional
import numpy as np

from .cache import ModelCacheManager, CATALOG
from .manifest import ModelManifest
from .memory import MemoryEstimate, check_memory_admission, acquire_engine_lock, release_engine_lock
from .runtime.subprocess import SubprocessVLMRuntime
from .result import VLMResult
from ..io.loader import load_image, save_image
from ..transforms.functional import resize
from ..errors import InsufficientMemoryError, ModelNotFoundError

class VLMContext:
    """
    Context manager wrapper for loaded VLM inference engine.
    """
    def __init__(
        self,
        runtime: SubprocessVLMRuntime,
        manifest: ModelManifest,
        warning_msg: Optional[str] = None
    ):
        self.runtime = runtime
        self.manifest = manifest
        self.warning_msg = warning_msg
        self._closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        if not self._closed:
            self._closed = True
            try:
                self.runtime.close()
            finally:
                release_engine_lock()

    def describe(
        self,
        image: Union[str, np.ndarray],
        prompt: Optional[str] = None,
        max_tokens: int = 150,
        temperature: float = 0.2
    ) -> VLMResult:
        if self._closed:
            raise RuntimeError("Cannot execute inference on closed VLMContext.")

        default_prompt = "이 사진 속 인물의 표정, 옷차림, 자세, 그리고 배경 환경을 한국어로 간결하게 요약 설명해줘."
        actual_prompt = prompt if prompt is not None else default_prompt

        temp_path = None
        if isinstance(image, str):
            if not os.path.exists(image):
                raise FileNotFoundError(f"Input image not found: {image}")
            raw = load_image(image)
            res = resize(raw, (self.manifest.preferred_resolution, self.manifest.preferred_resolution))
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
                temp_path = tmp.name
            save_image(res, temp_path, quality=90)
            target_file = temp_path
        elif isinstance(image, np.ndarray):
            res = resize(image, (self.manifest.preferred_resolution, self.manifest.preferred_resolution))
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
                temp_path = tmp.name
            save_image(res, temp_path, quality=90)
            target_file = temp_path
        else:
            raise ValueError("Input image must be a file path string or NumPy ndarray.")

        try:
            result = self.runtime.execute(
                image_path=target_file,
                prompt=actual_prompt,
                max_tokens=max_tokens,
                temperature=temperature
            )
            if self.warning_msg:
                result = VLMResult(
                    text=result.text,
                    finish_reason=result.finish_reason,
                    input_tokens=result.input_tokens,
                    output_tokens=result.output_tokens,
                    metrics=result.metrics,
                    warnings=tuple(list(result.warnings) + [self.warning_msg])
                )
            return result
        finally:
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)

    def ask(self, image: Union[str, np.ndarray], question: str) -> str:
        if not question or not question.strip():
            raise ValueError("Question cannot be empty.")
        res = self.describe(image, prompt=question)
        return res.text

def load(
    model_id: str = "smolvlm-500m-q4",
    device: str = "auto",
    threads: Union[int, str] = "auto",
    memory_policy: str = "warn",
    memory_budget_mb: Optional[int] = None,
    fallback: bool = True,
    allow_download: bool = False,
    cache_root: Optional[str] = None
) -> VLMContext:
    """
    Loads a VLM inference engine.
    - memory_policy: 'warn' (default), 'strict', 'unrestricted'
    - device: 'auto', 'cpu', 'vulkan', 'vulkan-force'
    - fallback: True (CPU retry on Vulkan error) or False (strict report)
    """
    cache = ModelCacheManager(cache_root=cache_root)

    # 1. Manifest Resolution
    manifest = cache.get_manifest(model_id)

    # 2. Admission Evaluation (Warn / Strict / Unrestricted)
    estimate = MemoryEstimate(
        model_weights_mb=int(manifest.estimated_memory_mb * 0.5),
        vision_encoder_mb=int(manifest.estimated_memory_mb * 0.25),
        kv_cache_mb=int(manifest.estimated_memory_mb * 0.15),
        compute_buffers_mb=int(manifest.estimated_memory_mb * 0.05),
        runtime_overhead_mb=int(manifest.estimated_memory_mb * 0.05),
        estimated_peak_mb=manifest.estimated_memory_mb,
        confidence="estimated"
    )
    _, warning_msg = check_memory_admission(
        estimate,
        user_budget_mb=memory_budget_mb,
        memory_policy=memory_policy
    )

    acquire_engine_lock()

    try:
        if not cache.is_model_installed(model_id):
            if allow_download:
                cache.install(model_id)
            else:
                legacy_file = os.path.expanduser("~/.cache/vlm_models/Qwen2-VL-2B-Instruct-Q4_K_M.gguf")
                if model_id.startswith("qwen") and os.path.exists(legacy_file):
                    pass
                else:
                    raise ModelNotFoundError(
                        f"Model '{model_id}' is not installed locally. Use allow_download=True or 'termux-vision model install {model_id}'."
                    )

        model_dir = cache.get_model_dir(model_id)

        # 3. Thread Resolution
        actual_threads = 4
        if isinstance(threads, int):
            actual_threads = max(1, min(8, threads))

        # 4. Backend Device Strategy
        actual_backend = "cpu"
        dev = device.lower().strip()
        if dev in ("vulkan", "vulkan-force", "gpu"):
            actual_backend = "vulkan"

        runtime = SubprocessVLMRuntime(
            manifest=manifest,
            model_dir=model_dir,
            threads=actual_threads,
            backend=actual_backend
        )

        return VLMContext(runtime=runtime, manifest=manifest, warning_msg=warning_msg)
    except Exception:
        release_engine_lock()
        raise
