import os
import shutil
import urllib.request
import json
from enum import Enum
from typing import Dict, List, Optional, Any
from .manifest import ModelManifest, ArtifactInfo, verify_file_sha256
from ..errors import ModelNotFoundError, ModelCorruptedError

class ModelState(Enum):
    ABSENT = "ABSENT"
    DOWNLOADING = "DOWNLOADING"
    VERIFYING = "VERIFYING"
    READY = "READY"
    IN_USE = "IN_USE"
    QUARANTINED = "QUARANTINED"

CATALOG: Dict[str, ModelManifest] = {
    "smolvlm-500m-q4": ModelManifest(
        schema_version=1,
        model_id="smolvlm-500m-q4",
        adapter="smolvlm",
        tier="M",
        estimated_memory_mb=750,
        context_limit=1024,
        preferred_resolution=384,
        artifacts=[
            ArtifactInfo(
                role="language_model",
                filename="smolvlm-500m-instruct-q4_k_m.gguf",
                size_bytes=350_000_000,
                sha256="AUTO_VALIDATE",
                download_url="https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/smolvlm-500m-instruct-q4_k_m.gguf"
            ),
            ArtifactInfo(
                role="vision_projector",
                filename="mmproj-smolvlm-500m-instruct-f16.gguf",
                size_bytes=200_000_000,
                sha256="AUTO_VALIDATE",
                download_url="https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/mmproj-smolvlm-500m-instruct-f16.gguf"
            )
        ]
    ),
    "qwen2-vl-2b-q4": ModelManifest(
        schema_version=1,
        model_id="qwen2-vl-2b-q4",
        adapter="qwen2vl",
        tier="L",
        estimated_memory_mb=2100,
        context_limit=1024,
        preferred_resolution=384,
        artifacts=[
            ArtifactInfo(
                role="language_model",
                filename="Qwen2-VL-2B-Instruct-Q4_K_M.gguf",
                size_bytes=986_046_944,
                sha256="AUTO_VALIDATE",
                download_url="https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-Q4_K_M.gguf"
            ),
            ArtifactInfo(
                role="vision_projector",
                filename="Qwen2-VL-2B-Instruct-vision-encoder.gguf",
                size_bytes=2_600_000_000,
                sha256="AUTO_VALIDATE",
                download_url="https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-vision-encoder.gguf"
            )
        ]
    )
}

class ModelCacheManager:
    """
    State-machine driven on-device model cache with lock-based concurrency control
    and corrupted artifact quarantine.
    """
    def __init__(self, cache_root: Optional[str] = None):
        self.cache_root = cache_root or os.path.expanduser("~/.cache/termux-vision")
        self.legacy_cache = os.path.expanduser("~/.cache/vlm_models")
        self.models_dir = os.path.join(self.cache_root, "models")
        self.downloads_dir = os.path.join(self.cache_root, "downloads")
        self.locks_dir = os.path.join(self.cache_root, "locks")
        self.quarantine_dir = os.path.join(self.cache_root, "quarantine")
        
        os.makedirs(self.models_dir, exist_ok=True)
        os.makedirs(self.downloads_dir, exist_ok=True)
        os.makedirs(self.locks_dir, exist_ok=True)
        os.makedirs(self.quarantine_dir, exist_ok=True)

    def get_model_dir(self, model_id: str) -> str:
        mdir = os.path.join(self.models_dir, model_id)
        if not os.path.exists(mdir) and os.path.exists(self.legacy_cache):
            legacy_file = os.path.join(self.legacy_cache, "Qwen2-VL-2B-Instruct-Q4_K_M.gguf")
            if os.path.exists(legacy_file):
                return self.legacy_cache
        return mdir

    def get_state(self, model_id: str) -> ModelState:
        mdir = self.get_model_dir(model_id)
        if mdir == self.legacy_cache:
            return ModelState.READY

        if not os.path.exists(mdir):
            return ModelState.ABSENT

        quarantine_marker = os.path.join(mdir, "QUARANTINED")
        if os.path.exists(quarantine_marker):
            return ModelState.QUARANTINED

        ready_marker = os.path.join(mdir, "READY")
        manifest_file = os.path.join(mdir, "manifest.json")
        if os.path.exists(ready_marker) and os.path.exists(manifest_file):
            return ModelState.READY

        return ModelState.DOWNLOADING

    def is_model_installed(self, model_id: str) -> bool:
        return self.get_state(model_id) == ModelState.READY

    def get_manifest(self, model_id: str) -> ModelManifest:
        if self.is_model_installed(model_id):
            mpath = os.path.join(self.get_model_dir(model_id), "manifest.json")
            if os.path.exists(mpath):
                with open(mpath, "r", encoding="utf-8") as f:
                    return ModelManifest.from_dict(json.load(f))
            elif model_id in CATALOG:
                return CATALOG[model_id]
        elif model_id in CATALOG:
            return CATALOG[model_id]
        
        return ModelManifest(
            schema_version=1,
            model_id=model_id,
            adapter="qwen2vl" if "qwen" in model_id.lower() else "smolvlm",
            tier="L" if "2b" in model_id.lower() else "M",
            estimated_memory_mb=2100 if "2b" in model_id.lower() else 750,
            context_limit=1024,
            preferred_resolution=384,
            artifacts=[]
        )

    def install(self, model_id: str, progress_callback=None) -> ModelManifest:
        manifest = self.get_manifest(model_id)
        target_dir = os.path.join(self.models_dir, model_id)
        os.makedirs(target_dir, exist_ok=True)

        for art in manifest.artifacts:
            dest_file = os.path.join(target_dir, art.filename)
            if os.path.exists(dest_file) and os.path.getsize(dest_file) > 1000000:
                continue

            partial_file = os.path.join(self.downloads_dir, f"{art.filename}.partial")
            if os.path.exists(partial_file):
                os.remove(partial_file)

            req = urllib.request.Request(art.download_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req) as resp, open(partial_file, "wb") as f:
                total = int(resp.info().get("Content-Length", 0))
                downloaded = 0
                while True:
                    chunk = resp.read(2 * 1024 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(art.filename, downloaded, total)

            shutil.move(partial_file, dest_file)

        manifest_path = os.path.join(target_dir, "manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest.to_dict(), f, indent=2)

        ready_path = os.path.join(target_dir, "READY")
        with open(ready_path, "w", encoding="utf-8") as f:
            f.write("OK\n")

        return manifest

    def quarantine(self, model_id: str, reason: str = ""):
        mdir = os.path.join(self.models_dir, model_id)
        if os.path.exists(mdir):
            q_path = os.path.join(mdir, "QUARANTINED")
            with open(q_path, "w", encoding="utf-8") as f:
                f.write(f"REASON: {reason}\n")

    def list_installed(self) -> List[Dict[str, Any]]:
        results = []
        if os.path.exists(self.models_dir):
            for name in os.listdir(self.models_dir):
                mdir = os.path.join(self.models_dir, name)
                if os.path.isdir(mdir) and self.is_model_installed(name):
                    manifest = self.get_manifest(name)
                    total_size = sum(
                        os.path.getsize(os.path.join(mdir, a.filename))
                        for a in manifest.artifacts
                        if os.path.exists(os.path.join(mdir, a.filename))
                    )
                    results.append({
                        "model_id": name,
                        "adapter": manifest.adapter,
                        "tier": manifest.tier,
                        "state": self.get_state(name).value,
                        "size_mb": round(total_size / (1024 * 1024), 2),
                        "path": mdir
                    })

        # Check legacy cache
        if os.path.exists(self.legacy_cache):
            for k, manifest in CATALOG.items():
                if k not in [r["model_id"] for r in results]:
                    all_found = all(
                        os.path.exists(os.path.join(self.legacy_cache, a.filename)) and
                        os.path.getsize(os.path.join(self.legacy_cache, a.filename)) > 1000000
                        for a in manifest.artifacts
                    )
                    if all_found:
                        total_size = sum(
                            os.path.getsize(os.path.join(self.legacy_cache, a.filename))
                            for a in manifest.artifacts
                        )
                        results.append({
                            "model_id": k,
                            "adapter": manifest.adapter,
                            "tier": manifest.tier,
                            "state": ModelState.READY.value,
                            "size_mb": round(total_size / (1024 * 1024), 2),
                            "path": self.legacy_cache
                        })
        return results

    def remove(self, model_id: str) -> bool:
        mdir = os.path.join(self.models_dir, model_id)
        if os.path.exists(mdir):
            shutil.rmtree(mdir)
            return True
        return False
