from dataclasses import dataclass
from typing import Optional, Tuple, Any, Dict

@dataclass(frozen=True)
class InferenceMetrics:
    backend: str
    model_id: str
    load_ms: Optional[float]
    vision_ms: float
    decode_ms: float
    tokens_per_second: float
    peak_rss_mb: Optional[float] = None

@dataclass(frozen=True)
class VLMResult:
    text: str
    finish_reason: str
    input_tokens: Optional[int]
    output_tokens: int
    metrics: InferenceMetrics
    warnings: Tuple[str, ...] = ()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "finish_reason": self.finish_reason,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "metrics": {
                "backend": self.metrics.backend,
                "model_id": self.metrics.model_id,
                "load_ms": self.metrics.load_ms,
                "vision_ms": self.metrics.vision_ms,
                "decode_ms": self.metrics.decode_ms,
                "tokens_per_second": self.metrics.tokens_per_second,
                "peak_rss_mb": self.metrics.peak_rss_mb
            },
            "warnings": list(self.warnings)
        }
