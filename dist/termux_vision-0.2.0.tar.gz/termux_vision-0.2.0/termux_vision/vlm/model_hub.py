import os
import subprocess
import urllib.request
from typing import Dict, Tuple

MODEL_REGISTRY: Dict[str, Dict[str, str]] = {
    "qwen2-vl-2b": {
        "text_url": "https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-Q4_K_M.gguf",
        "text_file": "Qwen2-VL-2B-Instruct-Q4_K_M.gguf",
        "vision_url": "https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-vision-encoder.gguf",
        "vision_file": "Qwen2-VL-2B-Instruct-vision-encoder.gguf",
        "size_mb": 3440,
        "default_res": 384
    },
    "smolvlm-500m": {
        "text_url": "https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/smolvlm-500m-instruct-q4_k_m.gguf",
        "text_file": "smolvlm-500m-instruct-q4_k_m.gguf",
        "vision_url": "https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/mmproj-smolvlm-500m-instruct-f16.gguf",
        "vision_file": "mmproj-smolvlm-500m-instruct-f16.gguf",
        "size_mb": 550,
        "default_res": 384
    }
}

def get_cache_dir() -> str:
    cache_dir = os.path.expanduser("~/.cache/termux_vision/vlm_models")
    # Also check legacy cache
    legacy_dir = os.path.expanduser("~/.cache/vlm_models")
    if os.path.exists(legacy_dir):
        return legacy_dir
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir

def download_vlm_model(model_name: str = "qwen2-vl-2b") -> Tuple[str, str]:
    """
    Downloads or retrieves cached VLM model weights (text GGUF and vision projector GGUF).
    """
    name_clean = model_name.lower().strip()
    if name_clean not in MODEL_REGISTRY:
        raise ValueError(f"Unknown VLM model: '{model_name}'. Available models: {list(MODEL_REGISTRY.keys())}")

    info = MODEL_REGISTRY[name_clean]
    cache_dir = get_cache_dir()

    text_dest = os.path.join(cache_dir, info["text_file"])
    vision_dest = os.path.join(cache_dir, info["vision_file"])

    for url, dest in [(info["text_url"], text_dest), (info["vision_url"], vision_dest)]:
        if not os.path.exists(dest) or os.path.getsize(dest) < 1000000:
            print(f"[*] Downloading {os.path.basename(dest)} from HuggingFace...")
            cmd = f"curl -L -f --retry 3 -o '{dest}' '{url}'"
            res = subprocess.run(cmd, shell=True)
            if res.returncode != 0 or os.path.getsize(dest) < 1000000:
                # Fallback to urllib streaming
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req) as resp, open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(2 * 1024 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)

    return text_dest, vision_dest
