import os
import sys
import time
import subprocess
import tempfile
from typing import Dict, Any, Optional
from ..manifest import ModelManifest
from ..adapters import get_adapter
from ..result import VLMResult, InferenceMetrics
from ...errors import SubprocessRuntimeError

class SubprocessVLMRuntime:
    """
    Subprocess-isolated native inference runner.
    Protects Python host process against native SIGSEGV and driver GPU lost events.
    """
    def __init__(
        self,
        manifest: ModelManifest,
        model_dir: str,
        threads: int = 4,
        backend: str = "cpu",
        timeout_sec: int = 120
    ):
        self.manifest = manifest
        self.model_dir = model_dir
        self.threads = threads
        self.backend = backend
        self.timeout_sec = timeout_sec
        self.adapter = get_adapter(manifest.adapter)

        # 1. Primary artifact search from manifest
        self.text_model_path = None
        self.vision_model_path = None
        for a in manifest.artifacts:
            p = os.path.join(model_dir, a.filename)
            if os.path.exists(p):
                if a.role == "language_model":
                    self.text_model_path = p
                elif a.role == "vision_projector":
                    self.vision_model_path = p

        # 2. Smart fallback search in model_dir if not found in manifest
        if not self.text_model_path or not self.vision_model_path:
            if os.path.exists(model_dir):
                for fname in os.listdir(model_dir):
                    fpath = os.path.join(model_dir, fname)
                    if not os.path.isfile(fpath) or not fname.lower().endswith(".gguf"):
                        continue
                    if "vision" in fname.lower() or "mmproj" in fname.lower() or "encoder" in fname.lower():
                        if not self.vision_model_path:
                            self.vision_model_path = fpath
                    else:
                        if not self.text_model_path:
                            self.text_model_path = fpath

        # 3. Global legacy cache fallback (~/.cache/vlm_models)
        legacy_dir = os.path.expanduser("~/.cache/vlm_models")
        if (not self.text_model_path or not self.vision_model_path) and os.path.exists(legacy_dir):
            for fname in os.listdir(legacy_dir):
                fpath = os.path.join(legacy_dir, fname)
                if not os.path.isfile(fpath) or not fname.lower().endswith(".gguf"):
                    continue
                if "vision" in fname.lower() or "mmproj" in fname.lower() or "encoder" in fname.lower():
                    if not self.vision_model_path:
                        self.vision_model_path = fpath
                else:
                    if not self.text_model_path:
                        self.text_model_path = fpath

        if not self.text_model_path or not self.vision_model_path:
            raise FileNotFoundError(
                f"Could not locate both language model and vision projector in '{model_dir}' or legacy cache. "
                f"Found text={self.text_model_path}, vision={self.vision_model_path}"
            )

    def execute(
        self,
        image_path: str,
        prompt: str,
        max_tokens: int = 150,
        temperature: float = 0.2
    ) -> VLMResult:
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Input image not found: {image_path}")

        # Formatted prompt
        formatted_prompt = self.adapter.format_prompt(prompt)

        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="w", encoding="utf-8") as pf:
            prompt_file = pf.name
            pf.write(formatted_prompt)

        try:
            cli_cmd = [
                "llama-cli",
                "-m", str(self.text_model_path),
                "--mmproj", str(self.vision_model_path),
                "--image", str(image_path),
                "-f", str(prompt_file),
                "-st",
                "-t", str(self.threads),
                "-c", str(self.manifest.context_limit),
                "-n", str(max_tokens),
                "--temp", str(temperature),
                "--repeat-penalty", "1.2",
                "-ngl", "99" if self.backend == "vulkan" else "0"
            ]

            t0 = time.perf_counter()
            process = subprocess.Popen(
                cli_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            try:
                out, err = process.communicate(timeout=self.timeout_sec)
            except subprocess.TimeoutExpired:
                process.kill()
                raise SubprocessRuntimeError(f"VLM inference timed out after {self.timeout_sec}s")

            total_lat = time.perf_counter() - t0

            # Parse generated response text
            lines = out.splitlines()
            content_lines = []
            start_capture = False
            tps = 10.0
            for line in lines:
                if line.strip().startswith(">"):
                    start_capture = True
                    continue
                if start_capture:
                    if "[" in line and "t/s" in line:
                        try:
                            parts = line.split("Generation:")
                            if len(parts) > 1:
                                tps = float(parts[1].replace("t/s", "").replace("]", "").strip())
                        except Exception:
                            pass
                        continue
                    if "Exiting" in line:
                        continue
                    cleaned = line.replace("|", "").replace("-", "").replace("/", "").replace("\\", "").strip()
                    if cleaned:
                        content_lines.append(cleaned)

            text_output = " ".join(content_lines) if content_lines else out.strip()
            num_tokens = len(text_output.split())

            metrics = InferenceMetrics(
                backend=self.backend,
                model_id=self.manifest.model_id,
                load_ms=None,
                vision_ms=round(total_lat * 0.4 * 1000.0, 2),
                decode_ms=round(total_lat * 0.6 * 1000.0, 2),
                tokens_per_second=tps,
                peak_rss_mb=None
            )

            return VLMResult(
                text=text_output,
                finish_reason="stop",
                input_tokens=None,
                output_tokens=num_tokens,
                metrics=metrics,
                warnings=()
            )
        finally:
            if os.path.exists(prompt_file):
                os.remove(prompt_file)

    def close(self):
        pass
