class TermuxVisionError(Exception):
    """Base exception for all termux-vision errors."""
    pass

class InsufficientMemoryError(TermuxVisionError):
    """Raised when estimated memory exceeds user memory budget or system available memory."""
    def __init__(self, required_mb: int, available_mb: int, recommendation: str = ""):
        msg = f"Required memory ({required_mb} MB) exceeds available memory budget ({available_mb} MB). {recommendation}".strip()
        super().__init__(msg)
        self.required_mb = required_mb
        self.available_mb = available_mb
        self.recommendation = recommendation

class ModelNotFoundError(TermuxVisionError):
    """Raised when requested model is not found or not installed."""
    pass

class ModelCorruptedError(TermuxVisionError):
    """Raised when model artifacts fail SHA-256 hash or integrity verification."""
    pass

class IncompatibleEmbeddingError(TermuxVisionError):
    """Raised when attempting to compute similarity across mismatched embedding spaces or dimensions."""
    pass

class VulkanDeviceLostError(TermuxVisionError):
    """Raised when Vulkan device encounters an unrecoverable hardware or driver fault."""
    pass

class DecompressionBombError(TermuxVisionError):
    """Raised when an image exceeds safe decompression size limits."""
    pass

class SubprocessRuntimeError(TermuxVisionError):
    """Raised when the process-isolated VLM runtime encounters a fatal exit or crash."""
    pass
