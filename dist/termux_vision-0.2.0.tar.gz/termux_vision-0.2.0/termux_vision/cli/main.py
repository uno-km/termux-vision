import argparse
import sys
import os
import json
import time

from .. import __version__
from ..io.loader import load_image, save_image, get_image_info
from ..transforms.functional import resize, to_grayscale
from ..cv.filters import canny
from ..cv.crop import crop
from ..detect.haar import HaarCascadeDetector, detect_faces
from .doctor import run_doctor
from ..vlm.cache import ModelCacheManager, CATALOG

EXIT_SUCCESS = 0
EXIT_ARG_ERROR = 2
EXIT_MODEL_NOT_FOUND = 10
EXIT_MODEL_VERIFY_FAIL = 11
EXIT_INSUFFICIENT_MEMORY = 12
EXIT_IMAGE_DECODE_FAIL = 14
EXIT_INFERENCE_FAIL = 15

def main():
    parser = argparse.ArgumentParser(
        prog="termux-vision",
        description=f"termux-vision CLI v{__version__}: High-performance on-device Computer Vision & Power-User VLM for Android Termux."
    )
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Command: doctor
    p_doc = subparsers.add_parser("doctor", help="Inspect device hardware, Vulkan GPU, and runtime environment")
    p_doc.add_argument("--json", action="store_true", help="Output diagnostic report in JSON format")
    p_doc.add_argument("--probe-vulkan", action="store_true", help="Run compute shader & matmul canary probe")
    p_doc.add_argument("--full", action="store_true", help="Run full model integrity and runtime check")

    # Command: model
    p_model = subparsers.add_parser("model", help="Manage VLM model artifacts and cache")
    p_model_sub = p_model.add_subparsers(dest="model_action", help="Model subcommands")
    
    p_m_list = p_model_sub.add_parser("list", help="List installed on-device models")
    p_m_list.add_argument("--json", action="store_true", help="Output list in JSON format")

    p_m_install = p_model_sub.add_parser("install", help="Download and verify a VLM model")
    p_m_install.add_argument("model_id", help="Model identifier (e.g. smolvlm-500m-q4, qwen2-vl-2b-q4)")

    p_m_remove = p_model_sub.add_parser("remove", help="Delete a model from local cache")
    p_m_remove.add_argument("model_id", help="Model identifier to delete")

    # Command: info
    p_info = subparsers.add_parser("info", help="Inspect image metadata")
    p_info.add_argument("image_path", help="Path to input image")

    # Command: canny
    p_canny = subparsers.add_parser("canny", help="Apply 5-stage Canny Edge Detection")
    p_canny.add_argument("image_path", help="Path to input image")
    p_canny.add_argument("-o", "--output", default="edges.png", help="Output path for edge image")
    p_canny.add_argument("--low", type=float, default=40.0, help="Low hysteresis threshold")
    p_canny.add_argument("--high", type=float, default=120.0, help="High hysteresis threshold")
    p_canny.add_argument("--resize", type=str, default=None, help="Resize image (e.g. 512x512)")

    # Command: detect-face
    p_face = subparsers.add_parser("detect-face", help="Detect human faces and crop")
    p_face.add_argument("image_path", help="Path to input image")
    p_face.add_argument("-o", "--output", default="face_crop.jpg", help="Output path for primary face crop")
    p_face.add_argument("--json", action="store_true", help="Output detection boxes in JSON format")

    # Command: vlm
    p_vlm = subparsers.add_parser("vlm", help="Run VLM Multimodal Image Description")
    p_vlm.add_argument("image_path", help="Path to input image")
    p_vlm.add_argument("-p", "--prompt", default=None, help="Text prompt query")
    p_vlm.add_argument("-m", "--model", default="smolvlm-500m-q4", help="Model ID (smolvlm-500m-q4, qwen2-vl-2b-q4)")
    p_vlm.add_argument("--device", default="auto", choices=["auto", "cpu", "vulkan", "vulkan-force"], help="Execution device backend")
    p_vlm.add_argument("--memory-policy", default="warn", choices=["warn", "strict", "unrestricted"], help="Memory admission policy")
    p_vlm.add_argument("--fallback", dest="fallback", action="store_true", default=True, help="Enable CPU fallback on GPU error")
    p_vlm.add_argument("--no-fallback", dest="fallback", action="store_false", help="Disable CPU fallback and report GPU error")
    p_vlm.add_argument("-t", "--threads", default="auto", help="Inference threads or 'auto'")
    p_vlm.add_argument("--max-tokens", type=int, default=150, help="Maximum generated tokens")
    p_vlm.add_argument("--json", action="store_true", help="Output full result and metrics in JSON format")

    # Command: benchmark
    p_bench = subparsers.add_parser("benchmark", help="Run on-device vision & VLM benchmark")
    p_bench.add_argument("image_path", nargs="?", default=None, help="Optional image path for VLM bench")
    p_bench.add_argument("-m", "--model", default="qwen2-vl-2b-q4", help="Model ID for benchmark")
    p_bench.add_argument("--device", default="auto", choices=["auto", "cpu", "vulkan", "vulkan-force"], help="Device backend")
    p_bench.add_argument("--memory-policy", default="unrestricted", choices=["warn", "strict", "unrestricted"])
    p_bench.add_argument("--runs", type=int, default=3, help="Benchmark run count")
    p_bench.add_argument("--json", action="store_true", help="Output benchmark results in JSON format")

    args = parser.parse_args()

    if args.command == "doctor":
        rep = run_doctor(probe_vulkan=getattr(args, "probe_vulkan", False), full_check=getattr(args, "full", False))
        if args.json:
            print(json.dumps(rep, indent=2))
        else:
            print("=== termux-vision Diagnostic Doctor ===")
            print(f"  Platform : {rep['platform']['system']} ({rep['platform']['machine']}) | Android: {rep['platform']['is_android']}")
            print(f"  RAM      : Total {rep['hardware']['total_ram_mb']}MB | Available {rep['hardware']['available_ram_mb']}MB")
            print(f"  CPU Cores: {rep['hardware']['cpu_cores']}")
            print(f"  Vulkan   : Lib: {rep['vulkan']['system_libvulkan']} | Adreno Driver: {rep['vulkan']['driver_so']} | Probe: {rep['vulkan']['probe_status']}")
            print(f"  Models   : {rep['vlm_runtime']['installed_models_count']} installed in {rep['vlm_runtime']['cache_dir']}")
            print(f"  Preset   : {rep['recommended_preset']}")
        sys.exit(EXIT_SUCCESS)

    elif args.command == "model":
        cache = ModelCacheManager()
        if args.model_action == "list":
            inst = cache.list_installed()
            if args.json:
                print(json.dumps(inst, indent=2))
            else:
                print(f"=== Installed VLM Models ({len(inst)}) ===")
                for m in inst:
                    print(f"  - {m['model_id']:<20} | Tier: {m['tier']} | State: {m.get('state', 'READY')} | Size: {m['size_mb']}MB")
                print("\nAvailable in Catalog:")
                for k, v in CATALOG.items():
                    print(f"  * {k:<20} | Tier: {v.tier} | Est. RAM: {v.estimated_memory_mb}MB")
            sys.exit(EXIT_SUCCESS)

        elif args.model_action == "install":
            print(f"[*] Installing model: {args.model_id}...")
            try:
                def on_prog(fname, d, t):
                    pct = (d / t * 100.0) if t > 0 else 0.0
                    print(f"\r  Downloading {fname}: {d/(1024*1024):.1f}/{t/(1024*1024):.1f}MB ({pct:.1f}%)", end="", flush=True)
                
                cache.install(args.model_id, progress_callback=on_prog)
                print(f"\n[+] Successfully installed and verified '{args.model_id}'.")
                sys.exit(EXIT_SUCCESS)
            except Exception as e:
                print(f"\n[-] Model installation failed: {e}")
                sys.exit(EXIT_MODEL_VERIFY_FAIL)

        elif args.model_action == "remove":
            if cache.remove(args.model_id):
                print(f"[+] Model '{args.model_id}' removed from cache.")
                sys.exit(EXIT_SUCCESS)
            else:
                print(f"[-] Model '{args.model_id}' was not found in cache.")
                sys.exit(EXIT_MODEL_NOT_FOUND)

    elif args.command == "info":
        info = get_image_info(args.image_path)
        print("=== Image Metadata ===")
        for k, v in info.items():
            print(f"  {k}: {v}")
        sys.exit(EXIT_SUCCESS)

    elif args.command == "canny":
        img = load_image(args.image_path)
        if args.resize:
            w, h = map(int, args.resize.split("x"))
            img = resize(img, (w, h))

        gray = to_grayscale(img)
        t0 = time.perf_counter()
        edges = canny(gray, low_threshold=args.low, high_threshold=args.high)
        lat = (time.perf_counter() - t0) * 1000.0
        save_image(edges, args.output, metadata="strip")
        print(f"[+] Canny edges computed in {lat:.2f}ms. Saved to {args.output}")
        sys.exit(EXIT_SUCCESS)

    elif args.command == "detect-face":
        img = load_image(args.image_path)
        detections = detect_faces(img)
        if args.json:
            res_dict = [
                {"bbox": d.bbox.to_xywh(), "score": d.score} for d in detections
            ]
            print(json.dumps({"count": len(detections), "detections": res_dict}, indent=2))
        else:
            print(f"[+] Detected {len(detections)} face regions.")
            if detections:
                print(f"    - Largest Face Box: {detections[0].bbox.to_xywh()}")
                face_crop = crop(img, detections[0].bbox, copy=False)
                save_image(face_crop, args.output, metadata="strip")
                print(f"[+] Saved primary face crop to {args.output}")
        sys.exit(EXIT_SUCCESS)

    elif args.command == "vlm":
        from ..vlm.api import load
        try:
            with load(
                model_id=args.model,
                device=args.device,
                memory_policy=args.memory_policy,
                fallback=args.fallback,
                threads=args.threads
            ) as engine:
                res = engine.describe(args.image_path, prompt=args.prompt, max_tokens=args.max_tokens)
                if args.json:
                    print(json.dumps(res.to_dict(), indent=2, ensure_ascii=False))
                else:
                    if res.warnings:
                        for w in res.warnings:
                            print(f"[!] WARNING: {w}", file=sys.stderr)
                    print(f"\n--- [VLM Result ({res.metrics.backend} | {res.metrics.tokens_per_second:.1f} t/s)] ---")
                    print(res.text)
            sys.exit(EXIT_SUCCESS)
        except Exception as e:
            print(f"[-] VLM Inference Error: {e}", file=sys.stderr)
            sys.exit(EXIT_INFERENCE_FAIL)

    elif args.command == "benchmark":
        print("=== termux-vision On-Device Benchmark ===")
        import numpy as np
        dummy = np.random.randint(0, 256, (512, 512, 3), dtype=np.uint8)
        
        t0 = time.perf_counter()
        res = resize(dummy, (256, 256))
        t_res = (time.perf_counter() - t0) * 1000.0
        print(f"  - Resize (512x512 -> 256x256): {t_res:.2f} ms")

        t1 = time.perf_counter()
        gray = to_grayscale(res)
        edges = canny(gray, 40, 120)
        t_can = (time.perf_counter() - t1) * 1000.0
        print(f"  - Grayscale & Canny Edge (256x256): {t_can:.2f} ms")

        detector = HaarCascadeDetector()
        t2 = time.perf_counter()
        boxes = detector.detect_multiscale(res, scale_factor=1.2, min_size=(32, 32))
        t_haar = (time.perf_counter() - t2) * 1000.0
        print(f"  - Haar Cascade Scan: {t_haar:.2f} ms")

        if args.image_path:
            print(f"\n[*] Running VLM benchmark on: {args.image_path}")
            from ..vlm.api import load
            with load(model_id=args.model, device=args.device, memory_policy=args.memory_policy) as engine:
                t_vlm_0 = time.perf_counter()
                vlm_res = engine.describe(args.image_path, max_tokens=64)
                lat_vlm = (time.perf_counter() - t_vlm_0) * 1000.0
                print(f"  - VLM Generation Latency: {lat_vlm:.1f} ms ({vlm_res.metrics.tokens_per_second:.1f} t/s)")
        print("[+] Benchmark Complete.")
        sys.exit(EXIT_SUCCESS)

    else:
        parser.print_help()
        sys.exit(EXIT_ARG_ERROR)

if __name__ == "__main__":
    main()
