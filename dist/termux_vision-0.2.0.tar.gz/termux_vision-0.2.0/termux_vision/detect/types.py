from dataclasses import dataclass
from typing import Tuple, Optional

@dataclass(frozen=True)
class BoundingBox:
    """
    Standard Bounding Box representation in (left, top, right, bottom) format.
    Right and bottom coordinates are EXCLUSIVE, matching Python slicing conventions.
    """
    left: int
    top: int
    right: int
    bottom: int

    @property
    def width(self) -> int:
        return max(0, self.right - self.left)

    @property
    def height(self) -> int:
        return max(0, self.bottom - self.top)

    @property
    def area(self) -> int:
        return self.width * self.height

    def to_xywh(self) -> Tuple[int, int, int, int]:
        return (self.left, self.top, self.width, self.height)

    @classmethod
    def from_xywh(cls, x: int, y: int, w: int, h: int) -> "BoundingBox":
        return cls(left=x, top=y, right=x + w, bottom=y + h)

@dataclass(frozen=True)
class Detection:
    """
    Object detection result container.
    """
    bbox: BoundingBox
    score: float
    class_id: Optional[int] = None
    class_name: Optional[str] = None
