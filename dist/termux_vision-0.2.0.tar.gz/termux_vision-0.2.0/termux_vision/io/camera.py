import os
import shutil
import subprocess
import tempfile
import time
import numpy as np
from .loader import load_image

class CameraCapture:
    """
    On-Device Camera interface for Android Termux via termux-camera-photo CLI
    with fallback to synthetic frame generator or V4L2 device.
    """
    def __init__(self, camera_id: int = 0):
        self.camera_id = camera_id
        self.has_termux_api = shutil.which("termux-camera-photo") is not None

    def capture_frame(self, output_path: str = None) -> np.ndarray:
        """
        Capture a photo directly from smartphone camera and return as RGB NumPy array.
        """
        if output_path is None:
            tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
            tmp_path = tmp.name
            tmp.close()
            cleanup = True
        else:
            tmp_path = os.path.expanduser(output_path)
            cleanup = False

        if self.has_termux_api:
            # Execute native Android camera CLI
            cmd = ["termux-camera-photo", "-c", str(self.camera_id), tmp_path]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if res.returncode != 0:
                if cleanup and os.path.exists(tmp_path):
                    os.remove(tmp_path)
                raise RuntimeError(f"termux-camera-photo failed: {res.stderr}")
            
            # Wait for file write
            time.sleep(0.1)
            arr = load_image(tmp_path, mode="RGB")
        else:
            # Synthetic camera frame for development & testing
            arr = np.zeros((480, 640, 3), dtype=np.uint8)
            # Create a simple test pattern
            arr[120:360, 160:480, 0] = 200  # Red rectangle
            arr[180:300, 240:400, 1] = 180  # Green inner
            arr[200:280, 280:360, 2] = 240  # Blue center

        if cleanup and os.path.exists(tmp_path):
            os.remove(tmp_path)

        return arr
