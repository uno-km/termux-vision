"""
termux-vision: Production-Grade On-Device Computer Vision & Isolated VLM Framework for Android Termux.
Zero PyTorch dependency, Pure NumPy & ARM64 NEON C-Accelerated kernels.
"""

__version__ = "0.2.0"
__author__ = "AMEVA Foundation / uno-km"
__license__ = "Apache-2.0"

from . import errors
from . import io
from . import transforms
from . import cv
from . import detect
from . import models
from . import bridge
from . import csrc
from . import vlm
from . import cli

from .detect.types import BoundingBox, Detection
from .detect.haar import detect_faces
from .models.embedding import Embedding, compute_similarity
from .vlm.api import load

__all__ = [
    "io",
    "transforms",
    "cv",
    "detect",
    "models",
    "bridge",
    "csrc",
    "vlm",
    "errors",
    "cli",
    "BoundingBox",
    "Detection",
    "detect_faces",
    "Embedding",
    "compute_similarity",
    "load",
    "__version__"
]
