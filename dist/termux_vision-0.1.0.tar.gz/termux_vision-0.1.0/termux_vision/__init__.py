"""
termux-vision: Native On-Device Computer Vision & Lightweight Neural Inference Framework for Android Termux.
"""

from . import io
from . import transforms
from . import cv
from . import detect
from . import models
from . import bridge

__version__ = "0.1.0"
__author__ = "AMEVA Open-Source Foundation (AOSF)"
__license__ = "Apache-2.0"

__all__ = [
    "io",
    "transforms",
    "cv",
    "detect",
    "models",
    "bridge",
    "__version__",
    "__author__",
    "__license__"
]
