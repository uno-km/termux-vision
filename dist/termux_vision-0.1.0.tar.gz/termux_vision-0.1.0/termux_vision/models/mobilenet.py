import numpy as np
from .conv_block import DepthwiseSeparableConv2D

class MobileNetV3FeatureExtractor:
    """
    Ultra-lightweight MobileNetV3-style Feature Extractor for ARM64 Edge Devices.
    Maps input image (3, H, W) -> compact 1D embedding vector (512-dim) for downstream classifier or LoRA.
    """
    def __init__(self, in_channels: int = 3, feature_dim: int = 512):
        self.feature_dim = feature_dim
        # 4-stage inverted bottleneck block stack
        self.block1 = DepthwiseSeparableConv2D(in_channels, 32, kernel_size=3, stride=2)
        self.block2 = DepthwiseSeparableConv2D(32, 64, kernel_size=3, stride=2)
        self.block3 = DepthwiseSeparableConv2D(64, 128, kernel_size=3, stride=2)
        self.block4 = DepthwiseSeparableConv2D(128, feature_dim, kernel_size=3, stride=2)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Input x: (3, H, W) or (B, 3, H, W)
        Output: (feature_dim,) or (B, feature_dim)
        """
        has_batch = (x.ndim == 4)
        if not has_batch:
            x_batched = x[np.newaxis, ...]
        else:
            x_batched = x

        h1 = self.block1(x_batched)
        h2 = self.block2(h1)
        h3 = self.block3(h2)
        h4 = self.block4(h3) # (B, feature_dim, H_out, W_out)

        # Global Average Pooling across spatial dimensions (axis 2, 3)
        pooled = np.mean(h4, axis=(2, 3)) # (B, feature_dim)

        if not has_batch:
            return pooled[0]
        return pooled

    def __call__(self, x: np.ndarray) -> np.ndarray:
        return self.forward(x)
