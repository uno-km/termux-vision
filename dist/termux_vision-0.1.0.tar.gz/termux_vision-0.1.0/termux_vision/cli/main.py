import argparse
import sys
import time
from ..io.loader import load_image, save_image, get_image_info
from ..io.camera import CameraCapture
from ..transforms.functional import resize, to_grayscale
from ..cv.filters import canny
from ..detect.haar import HaarCascadeDetector

def cmd_capture(args):
    print(f"[*] Capturing frame from camera #{args.camera}...")
    cam = CameraCapture(camera_id=args.camera)
    frame = cam.capture_frame(output_path=args.output)
    print(f"[+] Frame captured: shape={frame.shape}, saved to {args.output}")

def cmd_info(args):
    info = get_image_info(args.image)
    print("=== Image Metadata ===")
    for k, v in info.items():
        print(f"  {k}: {v}")

def cmd_canny(args):
    t0 = time.perf_counter()
    img = load_image(args.image)
    if args.resize:
        w, h = map(int, args.resize.split("x"))
        img = resize(img, (w, h))
    
    gray = to_grayscale(img)
    edges = canny(gray, low_threshold=args.low, high_threshold=args.high)
    elapsed = (time.perf_counter() - t0) * 1000.0

    save_image(edges, args.output)
    print(f"[+] Canny edges computed in {elapsed:.2f}ms. Saved to {args.output}")

def cmd_detect(args):
    t0 = time.perf_counter()
    img = load_image(args.image)
    detector = HaarCascadeDetector()
    boxes = detector.detect_multiscale(img, scale_factor=1.2)
    elapsed = (time.perf_counter() - t0) * 1000.0

    print(f"[+] Detection completed in {elapsed:.2f}ms. Found {len(boxes)} regions:")
    for idx, (x, y, w, h) in enumerate(boxes):
        print(f"  [{idx+1}] Box: x={x}, y={y}, w={w}, h={h}")

def cmd_bench(args):
    print("=== termux-vision On-Device Benchmark ===")
    import numpy as np
    sample = np.random.randint(0, 256, (512, 512, 3), dtype=np.uint8)
    
    # 1. Resize
    t0 = time.perf_counter()
    resized = resize(sample, (256, 256))
    t_res = (time.perf_counter() - t0) * 1000.0
    print(f"  - Resize (512x512 -> 256x256): {t_res:.2f} ms")

    # 2. Grayscale & Canny
    t1 = time.perf_counter()
    gray = to_grayscale(resized)
    edges = canny(gray, 50, 150)
    t_can = (time.perf_counter() - t1) * 1000.0
    print(f"  - Grayscale & Canny Edge (256x256): {t_can:.2f} ms")

    # 3. Haar Cascade
    t2 = time.perf_counter()
    detector = HaarCascadeDetector()
    _ = detector.detect_multiscale(resized, min_size=(24, 24))
    t_haar = (time.perf_counter() - t2) * 1000.0
    print(f"  - Haar Cascade Multiscale Scan: {t_haar:.2f} ms")

    print("[+] Benchmark Complete.")

def main():
    parser = argparse.ArgumentParser(prog="termux-vision", description="Native On-Device Computer Vision CLI for Termux")
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Capture
    p_cap = subparsers.add_parser("capture", help="Capture photo from smartphone camera")
    p_cap.add_argument("-c", "--camera", type=int, default=0, help="Camera ID (0: back, 1: front)")
    p_cap.add_argument("-o", "--output", default="capture.jpg", help="Output file path")

    # Info
    p_info = subparsers.add_parser("info", help="Get image metadata")
    p_info.add_argument("image", help="Target image path")

    # Canny
    p_can = subparsers.add_parser("canny", help="Apply Canny edge detection")
    p_can.add_argument("image", help="Input image path")
    p_can.add_argument("-o", "--output", default="edges.png", help="Output image path")
    p_can.add_argument("--low", type=float, default=50.0, help="Low threshold")
    p_can.add_argument("--high", type=float, default=150.0, help="High threshold")
    p_can.add_argument("--resize", help="Resize format: 512x512")

    # Detect
    p_det = subparsers.add_parser("detect", help="Detect faces and features")
    p_det.add_argument("image", help="Target image path")

    # Bench
    subparsers.add_parser("bench", help="Run on-device speed benchmark")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    cmd_map = {
        "capture": cmd_capture,
        "info": cmd_info,
        "canny": cmd_canny,
        "detect": cmd_detect,
        "bench": cmd_bench
    }
    cmd_map[args.command](args)

if __name__ == "__main__":
    main()
