import os
import io
import numpy as np
from PIL import Image, ImageOps

def load_image(path_or_bytes, mode: str = "RGB") -> np.ndarray:
    """
    Load an image from file path or raw bytes, apply EXIF orientation fix,
    and return as a contiguous NumPy array (H, W, C) or (H, W).
    """
    expanded_path = None
    if isinstance(path_or_bytes, str):
        expanded_path = os.path.expanduser(os.path.expandvars(path_or_bytes))
        if not os.path.exists(expanded_path):
            raise FileNotFoundError(f"Image file not found: {expanded_path}")
        with Image.open(expanded_path) as img:
            img = ImageOps.exif_transpose(img)
            if mode:
                img = img.convert(mode)
            arr = np.array(img)
    elif isinstance(path_or_bytes, (bytes, bytearray)):
        with Image.open(io.BytesIO(path_or_bytes)) as img:
            img = ImageOps.exif_transpose(img)
            if mode:
                img = img.convert(mode)
            arr = np.array(img)
    elif isinstance(path_or_bytes, np.ndarray):
        arr = path_or_bytes.copy()
    else:
        raise TypeError(f"Unsupported image input type: {type(path_or_bytes)}")

    return np.ascontiguousarray(arr)

def save_image(image_arr: np.ndarray, output_path: str, quality: int = 95) -> str:
    """
    Save a NumPy image array (uint8 or float [0, 1]) to file.
    """
    expanded_path = os.path.expanduser(os.path.expandvars(output_path))
    os.makedirs(os.path.dirname(os.path.abspath(expanded_path)), exist_ok=True)
    
    arr = image_arr
    if np.issubdtype(arr.dtype, np.floating):
        arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    elif arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        
    img = Image.fromarray(arr)
    img.save(expanded_path, quality=quality)
    return expanded_path

def get_image_info(path: str) -> dict:
    """
    Extract image metadata (format, dimensions, mode, file size in bytes) without loading all pixels into memory.
    """
    expanded_path = os.path.expanduser(os.path.expandvars(path))
    if not os.path.exists(expanded_path):
        raise FileNotFoundError(f"Image file not found: {expanded_path}")
    
    size_bytes = os.path.getsize(expanded_path)
    with Image.open(expanded_path) as img:
        return {
            "path": expanded_path,
            "width": img.width,
            "height": img.height,
            "format": img.format,
            "mode": img.mode,
            "size_bytes": size_bytes,
            "size_mb": round(size_bytes / (1024 * 1024), 3)
        }
