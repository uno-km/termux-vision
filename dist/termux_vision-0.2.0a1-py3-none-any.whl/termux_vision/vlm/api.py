import os
import tempfile
from typing import Union, Dict, Any, Optional
import numpy as np

from .cache import ModelCacheManager, CATALOG
from .manifest import ModelManifest, ArtifactInfo
from .memory import MemoryEstimate, check_memory_admission, acquire_engine_lock, release_engine_lock
from .runtime.subprocess import SubprocessVLMRuntime
from .runtime.resolver import RuntimeInfo, resolve_llama_cli
from .result import VLMResult
from ..io.loader import load_image, save_image
from ..transforms.functional import resize
from ..errors import (
    InsufficientMemoryError,
    ModelNotFoundError,
    NoInstalledModelsError,
    VulkanNotAvailableError
)

class VLMContext:
    """
    Context manager wrapper for loaded VLM inference engine.
    """
    def __init__(
        self,
        runtime: SubprocessVLMRuntime,
        manifest: ModelManifest,
        warning_msg: Optional[str] = None
    ):
        self.runtime = runtime
        self.manifest = manifest
        self.warning_msg = warning_msg
        self._closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        if not self._closed:
            self._closed = True
            try:
                self.runtime.close()
            finally:
                release_engine_lock()

    def describe(
        self,
        image: Union[str, np.ndarray],
        prompt: Optional[str] = None,
        max_tokens: int = 150,
        temperature: float = 0.2
    ) -> VLMResult:
        if self._closed:
            raise RuntimeError("Cannot execute inference on closed VLMContext.")

        default_prompt = "이 사진 속 인물의 표정, 옷차림, 자세, 그리고 배경 환경을 한국어로 간결하게 요약 설명해줘."
        actual_prompt = prompt if prompt is not None else default_prompt

        temp_path = None
        if isinstance(image, str):
            expanded_img = os.path.abspath(os.path.expanduser(image))
            if not os.path.exists(expanded_img):
                raise FileNotFoundError(f"Input image not found: {expanded_img}")
            raw = load_image(expanded_img)
            res = resize(raw, (self.manifest.preferred_resolution, self.manifest.preferred_resolution))
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
                temp_path = tmp.name
            save_image(res, temp_path, quality=90)
            target_file = temp_path
        elif isinstance(image, np.ndarray):
            res = resize(image, (self.manifest.preferred_resolution, self.manifest.preferred_resolution))
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
                temp_path = tmp.name
            save_image(res, temp_path, quality=90)
            target_file = temp_path
        else:
            raise ValueError("Input image must be a file path string or NumPy ndarray.")

        try:
            result = self.runtime.execute(
                image_path=target_file,
                prompt=actual_prompt,
                max_tokens=max_tokens,
                temperature=temperature
            )
            if self.warning_msg:
                result = VLMResult(
                    text=result.text,
                    finish_reason=result.finish_reason,
                    input_tokens=result.input_tokens,
                    output_tokens=result.output_tokens,
                    word_count=result.word_count,
                    metrics=result.metrics,
                    warnings=tuple(list(result.warnings) + [self.warning_msg])
                )
            return result
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    def ask(self, image: Union[str, np.ndarray], question: str) -> str:
        if not question or not question.strip():
            raise ValueError("Question cannot be empty.")
        res = self.describe(image, prompt=question)
        return res.text

def load(
    model_id: str = "smolvlm-500m-q4",
    device: str = "auto",
    threads: Union[int, str] = "auto",
    memory_policy: str = "warn",
    memory_budget_mb: Optional[int] = None,
    fallback: Optional[bool] = None,
    allow_download: bool = False,
    cache_root: Optional[str] = None,
    runtime_path: Optional[str] = None,
    mmproj_path: Optional[str] = None
) -> VLMContext:
    """
    Loads a VLM inference engine using verified runtime and installed model.
    Supports official catalog models, custom Hugging Face models, and direct local files.
    """
    cache = ModelCacheManager(cache_root=cache_root)

    # 1. Resolve real executable
    runtime_info = resolve_llama_cli(explicit_path=runtime_path)

    # 2. Check if model is a direct file path (Custom 싸제 GGUF)
    expanded_model = os.path.abspath(os.path.expanduser(str(model_id)))
    is_direct_file = os.path.isfile(expanded_model)

    if is_direct_file:
        model_dir = os.path.dirname(expanded_model)
        manifest, model_dir = cache.require_installed_model(expanded_model)
        custom_text_path = expanded_model
        custom_vision_path = os.path.abspath(os.path.expanduser(mmproj_path)) if mmproj_path else None
    else:
        # Check if download is required and allowed
        if allow_download and not cache.is_model_installed(model_id):
            cache.install(model_id)

        manifest, model_dir = cache.require_installed_model(model_id)
        custom_text_path = None
        custom_vision_path = os.path.abspath(os.path.expanduser(mmproj_path)) if mmproj_path else None

    # 3. User Freedom: Memory Admission Check (No arbitrary size blocking unless policy='strict')
    estimate = MemoryEstimate(
        model_weights_mb=int(manifest.estimated_memory_mb * 0.5),
        vision_encoder_mb=int(manifest.estimated_memory_mb * 0.25),
        kv_cache_mb=int(manifest.estimated_memory_mb * 0.15),
        compute_buffers_mb=int(manifest.estimated_memory_mb * 0.05),
        runtime_overhead_mb=int(manifest.estimated_memory_mb * 0.05),
        estimated_peak_mb=manifest.estimated_memory_mb,
        confidence="estimated"
    )
    _, warning_msg = check_memory_admission(
        estimate,
        user_budget_mb=memory_budget_mb,
        memory_policy=memory_policy
    )

    acquire_engine_lock()

    try:
        actual_threads = 4
        if isinstance(threads, int):
            actual_threads = max(1, min(8, threads))
        elif isinstance(threads, str) and threads != "auto":
            try:
                actual_threads = max(1, min(8, int(threads)))
            except ValueError:
                pass

        # 4. Strict Device & Fallback Policy (Rule 8 & 9)
        # auto: try vulkan, allow fallback to cpu if vulkan fails
        # gpu/vulkan: strictly enforce vulkan, reject fallback to cpu
        # cpu: pure cpu
        requested_device = device.lower().strip()
        if requested_device in ("vulkan", "vulkan-force", "gpu"):
            actual_backend = "vulkan"
            actual_fallback = False if fallback is None else fallback # Strict GPU mode: default NO silent fallback
        elif requested_device == "auto":
            actual_backend = "vulkan"
            actual_fallback = True if fallback is None else fallback # Auto mode: default fallback to CPU allowed
        else:
            actual_backend = "cpu"
            actual_fallback = False

        runtime = SubprocessVLMRuntime(
            manifest=manifest,
            model_dir=model_dir,
            executable=runtime_info.executable,
            threads=actual_threads,
            backend=actual_backend,
            fallback=actual_fallback,
            custom_text_model=custom_text_path,
            custom_vision_model=custom_vision_path
        )

        return VLMContext(runtime=runtime, manifest=manifest, warning_msg=warning_msg)
    except Exception:
        release_engine_lock()
        raise
