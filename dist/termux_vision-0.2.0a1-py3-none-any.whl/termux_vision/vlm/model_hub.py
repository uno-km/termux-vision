import os
import subprocess
import urllib.request
import urllib.error
from typing import Dict, Tuple, Optional, List, Any
from ..errors import ModelDownloadError

MODEL_REGISTRY: Dict[str, Dict[str, Any]] = {
    "qwen2-vl-2b": {
        "text_url": "https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-Q4_K_M.gguf",
        "text_file": "Qwen2-VL-2B-Instruct-Q4_K_M.gguf",
        "vision_url": "https://huggingface.co/second-state/Qwen2-VL-2B-Instruct-GGUF/resolve/main/Qwen2-VL-2B-Instruct-vision-encoder.gguf",
        "vision_file": "Qwen2-VL-2B-Instruct-vision-encoder.gguf",
        "size_mb": 3440,
        "default_res": 384
    },
    "smolvlm-500m": {
        "text_url": "https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/smolvlm-500m-instruct-q4_k_m.gguf",
        "text_file": "smolvlm-500m-instruct-q4_k_m.gguf",
        "vision_url": "https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct-GGUF/resolve/main/mmproj-smolvlm-500m-instruct-f16.gguf",
        "vision_file": "mmproj-smolvlm-500m-instruct-f16.gguf",
        "size_mb": 550,
        "default_res": 384
    }
}

def is_known_remote_model(model_name: str) -> bool:
    clean = model_name.lower().strip()
    return clean in MODEL_REGISTRY or clean.startswith("hf:") or "/" in clean

def get_cache_dir() -> str:
    cache_dir = os.path.expanduser("~/.cache/termux-vision/models")
    legacy_dir = os.path.expanduser("~/.cache/vlm_models")
    if os.path.exists(legacy_dir) and not os.path.exists(cache_dir):
        return legacy_dir
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir

def download_vlm_model(model_name: str = "smolvlm-500m", progress_callback=None) -> Tuple[str, str]:
    """
    Downloads or retrieves cached VLM model weights (text GGUF and vision projector GGUF).
    """
    name_clean = model_name.lower().strip()
    if name_clean not in MODEL_REGISTRY:
        raise ModelDownloadError(
            model_source=model_name,
            reason=f"Unknown VLM model identifier. Available presets: {list(MODEL_REGISTRY.keys())}"
        )

    info = MODEL_REGISTRY[name_clean]
    cache_dir = os.path.join(get_cache_dir(), name_clean)
    os.makedirs(cache_dir, exist_ok=True)

    text_dest = os.path.join(cache_dir, info["text_file"])
    vision_dest = os.path.join(cache_dir, info["vision_file"])

    for url, dest in [(info["text_url"], text_dest), (info["vision_url"], vision_dest)]:
        if not os.path.exists(dest) or os.path.getsize(dest) == 0:
            print(f"[*] Downloading {os.path.basename(dest)} from HuggingFace...")
            partial_dest = dest + ".partial"
            if os.path.exists(partial_dest):
                os.remove(partial_dest)

            try:
                # OpenSSF & CWE-78 Compliant argument list execution (shell=False)
                cmd = ["curl", "-L", "-f", "--retry", "3", "-o", str(partial_dest), str(url)]
                res = subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode != 0 or not os.path.exists(partial_dest) or os.path.getsize(partial_dest) == 0:
                    # Fallback to urllib streaming
                    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (termux-vision)"})
                    with urllib.request.urlopen(req) as resp, open(partial_dest, "wb") as f:
                        total = int(resp.info().get("Content-Length", 0))
                        downloaded = 0
                        while True:
                            chunk = resp.read(2 * 1024 * 1024)
                            if not chunk:
                                break
                            f.write(chunk)
                            downloaded += len(chunk)
                            if progress_callback:
                                progress_callback(os.path.basename(dest), downloaded, total)

                if os.path.exists(dest):
                    os.remove(dest)
                os.replace(partial_dest, dest)
            except Exception as e:
                if os.path.exists(partial_dest):
                    os.remove(partial_dest)
                raise ModelDownloadError(
                    model_source=url,
                    reason=f"Network download failure: {e}"
                )

    return text_dest, vision_dest
